import java.util.Scanner;

public class Main 
{
	public static int ibaCelaCisla(Scanner sc) 
	{
		int cislo = 0;
		try
		{
			cislo = sc.nextInt();
		}
		catch(Exception e)
		{
			System.out.println("Nastala vyjimka typu "+e.toString());
			System.out.println("zadejte prosim cele cislo ");
			cislo = ibaCelaCisla(sc);
		}
		return cislo;
	}
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Kniznica mojaKniznica = new Kniznica();
		SQL sql = new SQL();
		sql.pripojit();
		sql.vytvorit_tabulku();
		sql.nacitat_tabulku();
		int volba;
		boolean run = true;
		while(run)
		{
			for (int i = 0; i < 50; ++i) System.out.println(); 
		    
		    
			System.out.println("\nVyberte činnosť: 		\n\n"
					+ "1. vytvoreniť novú knižnicu 		\n"
					+ "2. načítanie knihy zo súboru 	\n"
					+ "3. uloženie knihy do súboru 		\n\n"
					+ "4. pridať novú knihu 			\n"
					+ "5. odstrániť knihu 				\n"
					+ "6. upraviť vlastnosti knihy 		\n\n"
					+ "7. výpis vlastností knihy 		\n"
					+ "8. výpis celej knižnice 			\n\n"
					+ "9. ukončenie systému 			\n");
			
			volba=ibaCelaCisla(sc);
			switch(volba)
			{
				case 1:
					mojaKniznica.nova_kniznica();
					break;
				
				case 2:
					System.out.println("Zadajte názov súboru: ");
					mojaKniznica.nacitat_knihu(sc.next());
					break;
					
				case 3:
					System.out.println("Zadajte názov súboru: ");
					mojaKniznica.ulozit_knihu(sc.next());
					break;
					
				case 4:
					mojaKniznica.pridat_knihu();
					break;
				
				case 5:
					mojaKniznica.odstranit_knihu();
					break;
				
				case 6:
					mojaKniznica.upravit_knihu();
					break;
				
				case 7:
					mojaKniznica.vypisat_knihu();
					break;
				
				case 8:
					mojaKniznica.vypisat_kniznicu();
					break;
				
				case 9:
					System.out.println("Uložiť zmeny? a/n");
					if(sc.next() == "a") mojaKniznica.ulozit_kniznicu();
					sql.odpojit();
					run = false;
					break;
			}
		}
	}
}
