
public class Roman extends Kniha
{
	private String zaner;
	
	Roman(String nazov, String zaner, String autor, int rok_vydania, boolean stav_dostupnosti)
	{
		super(nazov,autor,rok_vydania,stav_dostupnosti);
		this.zaner = zaner;
	}

	public String getZaner() {return zaner;}

	public void setZaner(String zaner)
	{
		Kniznica kn = new Kniznica();
		this.zaner = kn.najdi_zaner(zaner);
	}
}
