
public class Ucebnica extends Kniha
{
	private String rocnik;
	
	Ucebnica(String nazov, String rocnik, String autor, int rok_vydania, boolean stav_dostupnosti)
	{
		super(nazov, autor, rok_vydania, stav_dostupnosti);
		this.rocnik = rocnik;
	}

	public String getRocnik() {return rocnik;}

	public void setRocnik(String rocnik) {this.rocnik = rocnik;}
}
