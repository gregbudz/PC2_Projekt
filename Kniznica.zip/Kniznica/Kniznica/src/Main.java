import java.util.InputMismatchException;
import java.util.Scanner;

public class Main 
{
	public static int over_cislo(Scanner sc) 
	{
		int cislo = 0;
		boolean platne_cislo = false;
	    while (!platne_cislo) 
	    {
	        try 
	        {
	            cislo = sc.nextInt();
	            platne_cislo = true;
	        } 
	        
	        catch (InputMismatchException e) 
	        {
	            System.out.println("Zadajte prosím celé číslo");
	            sc.next();
	        }
	    }
	    return cislo;
	}
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Kniznica mojaKniznica = new Kniznica();
		SQL sql = new SQL();
		sql.pripojit();
		sql.vytvorit_tabulku();
		sql.nacitat_tabulku();
		int volba;
		boolean run = true;
		boolean vymazat = false;
		while(run)
		{
			for (int i = 0; i < 20; ++i) System.out.println(); 
		    
		    
			System.out.println("\nVyberte možnosť: 		\n\n"
					+ "1. vytvoriť novú knižnicu 		\n"
					+ "2. načítanie knihy zo súboru 	\n"
					+ "3. uloženie knihy do súboru 		\n\n"
					+ "4. pridať novú knihu 			\n"
					+ "5. odstrániť knihu 				\n"
					+ "6. upraviť vlastnosti knihy 		\n\n"
					+ "7. výpis vlastností knihy 		\n"
					+ "8. výpis celej knižnice 			\n\n"
					+ "9. ukončenie systému 			\n");
			
			volba = over_cislo(sc);
			switch(volba)
			{
				case 1:
					mojaKniznica.nova_kniznica();
					vymazat = true;
					break;
				
				case 2:
					System.out.println("Zadajte názov súboru: ");
					mojaKniznica.nacitat_knihu(sc.next());
					break;
					
				case 3:
					System.out.println("Zadajte názov súboru: ");
					mojaKniznica.ulozit_knihu(sc.next());
					break;
					
				case 4:
					mojaKniznica.pridat_knihu();
					break;
				
				case 5:
					mojaKniznica.odstranit_knihu();
					break;
				
				case 6:
					mojaKniznica.upravit_knihu();
					break;
				
				case 7:
					mojaKniznica.vypisat_knihu();
					break;
				
				case 8:
					mojaKniznica.vypisat_kniznicu();
					break;
				
				case 9:
					System.out.println("Uložiť zmeny? a/n");
					String vol = sc.next().toLowerCase();
					if (vol.equals("a")) 
					{
						if(vymazat) sql.vymazat_tabulku();
						mojaKniznica.ulozit_kniznicu();
					}
					sql.odpojit();
					run = false;
					break;
			}
		}
	}
}
