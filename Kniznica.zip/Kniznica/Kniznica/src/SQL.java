import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SQL
{
	private static volatile Connection conn;
	
	public boolean pripojit()
	{
		conn = null; 
		
		try {conn = DriverManager.getConnection("jdbc:sqlite:kniznica.db");}
		catch (SQLException e)
		{
			System.out.println(e.getMessage());
			return false;
		}
		return true;
	}
	
	public void odpojit()
	{
		if (conn != null)
		{
			try {conn.close();}
			catch (SQLException e) {System.out.println(e.getMessage());}
		}
	}
	
	public boolean vytvorit_tabulku() 
	{
	    if (conn == null) return false;
	    String sql = "CREATE TABLE IF NOT EXISTS kniznica ("
	            + "nazov varchar(255) NOT NULL,"
	            + "typ varchar(255) NOT NULL,"
	            + "typ_info varchar(255) NOT NULL,"
	            + "autori varchar(255) NOT NULL,"
	            + "rok smallint NOT NULL,"
	            + "stav bit NOT NULL);";
	    try {
	        Statement stmt = conn.createStatement();
	        stmt.execute(sql);
	        return true;
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	    return false;
	}
	
	public boolean vymazat_tabulku()
	{
		if (conn == null) return false;
		String sql = "DELETE FROM kniznica";
		try 
        {
        	Statement stmt = conn.createStatement();
        	stmt.execute(sql);
        	return true;
        } catch (SQLException e) {System.out.println(e.getMessage());}
		return false;
	}
	
	public void nacitat_tabulku() 
	{
	    String sql = "SELECT nazov, typ, typ_info, autori, rok, stav FROM kniznica";
	    Kniznica kniznica = new Kniznica();
	    Kniha kniha = null;
	    try 
	    {
	        Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery(sql);
	        while (rs.next()) 
	        {
	            List<String> aut = new ArrayList<>();
	            String[] autori = rs.getString("autori").split(", ");
	            aut.addAll(Arrays.asList(autori));
	            if (rs.getString("typ").equals("Roman")) kniha = new Roman(rs.getString("nazov"), rs.getString("typ_info"), aut, rs.getInt("rok"), rs.getBoolean("stav"));
	            if (rs.getString("typ").equals("Ucebnica")) kniha = new Ucebnica(rs.getString("nazov"), rs.getString("typ_info"), aut, rs.getInt("rok"), rs.getBoolean("stav"));
	            kniznica.nacitat_knihu_z_sql(rs.getString("nazov"), kniha);
	        }
	        
	    } 
	    catch (SQLException e) {System.out.println(e.getMessage());}
	}
	
	public void ulozit_do_tabulky(String nazov, String typ, String typ_info, List<String> autori, int rok, boolean stav)
	{
		String sql = "INSERT INTO kniznica(nazov,typ,typ_info,autori,rok,stav) VALUES(?,?,?,?,?,?)";
        try 
        {
        	PreparedStatement pstmt = conn.prepareStatement(sql); 
	        pstmt.setString(1, nazov);
	        pstmt.setString(2, typ);
	        pstmt.setString(3, typ_info);
	        pstmt.setString(4, String.join(", ", autori));
	        pstmt.setInt(5, rok);
	        pstmt.setBoolean(6, stav);
	        pstmt.executeUpdate();   
        } 
        catch (SQLException e) {System.out.println(e.getMessage());}
	}
}
