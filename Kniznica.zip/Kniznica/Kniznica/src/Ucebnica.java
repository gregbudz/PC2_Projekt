import java.util.List;

public class Ucebnica extends Kniha
{
	private String rocnik;
	
	Ucebnica(String nazov, String rocnik, List<String> autori, int rok_vydania, boolean stav_dostupnosti)
	{
		super(nazov, autori, rok_vydania, stav_dostupnosti);
		this.rocnik = rocnik;
	}

	public String getRocnik() {return rocnik;}

	public void setRocnik(String rocnik) {this.rocnik = rocnik;}
}
