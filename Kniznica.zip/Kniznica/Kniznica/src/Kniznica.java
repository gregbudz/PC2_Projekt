import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Kniznica 
{
	private Scanner sc;
	private static HashMap <String, Kniha> knihy;
	private String[] zanre = new String[]{"fantasy","drama","thriller","crime","history"};
	
	public Kniznica()
	{
		knihy = new HashMap<String,Kniha>();
		sc = new Scanner(System.in);
	}
	
	public String najdi_zaner(String zaner)
	{
		while (true)
		{
			for (int i = 0; i<zanre.length; i++) if (zanre[i].contentEquals(zaner)) return zaner;
			System.out.println("Zadajte jeden zo žánrov.");
			zaner = sc.next().toLowerCase();
		}
	}
	
	public String stav(boolean dostupnost)
	{
		if (dostupnost) return "na sklade";
		return "požičané";
	}
	
	public void nova_kniznica(){knihy.clear();}
	
	public void nacitat_knihu_z_sql(String nazov, Kniha kniha)
	{
		knihy.put(nazov, kniha);
	}
	
	public void pridat_knihu()
	{
		System.out.println("Zadajte typ knihy, ktorú si prajete pridať: 1 Román 2 Učebnica");
		int typ = Main.over_cislo(sc);
		while (typ != 1 && typ != 2)
		{
			System.out.println("Prosím zadajte 1 alebo 2: ");
			typ = Main.over_cislo(sc);
		}
		
		System.out.println("Zadajte názov knihy: ");
		String naz = sc.next().toLowerCase();
		
		List<String> aut = new ArrayList<>();
		System.out.println("Zadajte počet autorov: ");
		int pocet_a = Main.over_cislo(sc);
		
		for (int i = 0; i < pocet_a; i++)
		{
			System.out.println("Zadajte meno autora: ");
			aut.add(sc.next().toLowerCase());
		}
		
		System.out.println("Zadajte rok vydania: ");
		int rok = Main.over_cislo(sc);
		while(rok > 2025 || rok < 1000)
		{
			System.out.println("Prosím zadajte skutočný rok vydania: ");
			rok = Main.over_cislo(sc);
		}
		
		System.out.println("Zadajte stav dostupnosti: sklad/pozic");
		boolean stav = false;
		if (sc.next().toLowerCase().equals("sklad")) stav = true;
		
		switch(typ)
		{
			case 1:
				System.out.println("Zadajte žáner: Fantasy/Drama/Thriller/Crime/History");
				String zan = sc.next().toLowerCase();
				zan = najdi_zaner(zan);
				knihy.put(naz, new Roman(naz,zan,aut,rok,stav));
				break;
			
			case 2:
				System.out.println("Zadajte ročník študentov: ");
				String roc = sc.next();
				knihy.put(naz, new Ucebnica(naz,roc,aut,rok,stav));
				break;
		}
	}

	public void odstranit_knihu()
	{
		System.out.println("Zadajte názov knihy: ");
		
		try
		{
			String naz = sc.next().toLowerCase();
			System.out.println("Ste si istý s odstránením " + naz + "? a/n");
			String volba = sc.next();
			if (volba.equals("a")) knihy.remove(naz);
		}
		
		catch(NoSuchElementException e)
		{
			 System.out.println("Taká kniha neexistuje v knižnici.");
			 sc.nextLine();
		}
	}
	
	public void upravit_knihu()
	{
		System.out.println("Zadajte názov knihy: ");
		
		try
		{
			String naz = sc.next().toLowerCase();
			String novy_naz = null;
			
			String zan = null;
			if (knihy.get(naz) instanceof Roman)zan = ((Roman)knihy.get(naz)).getZaner();
			
			String roc = null;
			if (knihy.get(naz) instanceof Ucebnica)roc = ((Ucebnica)knihy.get(naz)).getRocnik();
			
			List<String> aut = knihy.get(naz).getAutori();
			int rok = knihy.get(naz).getRok();
			boolean stav = knihy.get(naz).getStav();
			
			int volba;
			boolean zmena_naz = false;
			boolean run = true;
			while(run)
			{
				if (knihy.get(naz) instanceof Roman) 
				{
					knihy.remove(naz);
					if (zmena_naz) 
					{
						naz = novy_naz;
						zmena_naz = false;
						novy_naz = null;
					}
					knihy.put(naz, new Roman(naz,zan,aut,rok,stav));
				}
					
				else if (knihy.get(naz) instanceof Ucebnica) 
				{
					knihy.remove(naz);
					if (zmena_naz) 
					{
						naz = novy_naz;
						zmena_naz = false;
						novy_naz = null;
					}
					knihy.put(naz, new Ucebnica(naz,roc,aut,rok,stav));
				}
				
				System.out.println("Vyberte si, čo by ste chceli upraviť na " + naz + ": \n" 
						+ "1. názov");
				if (knihy.get(naz) instanceof Roman)System.out.println("2. žáner");
				else if (knihy.get(naz) instanceof Ucebnica)System.out.println("2. ročník");
				System.out.println("3. autorov	\n"
						+ "4. rok vydania		\n"
						+ "5. stav dostupnosti	\n"
						+ "6. ukončiť úpravu	\n");
				
				volba = Main.over_cislo(sc);
				switch(volba)
				{
					case 1:
						System.out.println("Zadajte názov knihy: ");
						novy_naz = sc.next().toLowerCase();
						zmena_naz = true;
						break;
						
					case 2:
						if (knihy.get(naz) instanceof Roman)
						{
							System.out.println("Zadajte žáner knihy: ");
							zan = sc.next().toLowerCase();
							zan = najdi_zaner(zan);
						}
						else if (knihy.get(naz) instanceof Ucebnica)
						{
							System.out.println("Zadajte ročník študentov: ");
							roc = sc.next();
						}
						break;
						
					case 3:
						System.out.println("\n Odstrániť všetkých autorov? a/n");
						
						if (sc.next().equals("a")) aut.clear();
						System.out.println("Zadajte počet autorov: ");
						int pocet_a = Main.over_cislo(sc);
						
						for (int i = 0; i < pocet_a; i++)
						{
							System.out.println("Zadajte meno autora: ");
							aut.add(sc.next().toLowerCase());
						}
						break;
						
					case 4:
						System.out.println("Zadajte rok vydania: ");
						rok =  Main.over_cislo(sc);
						while(rok > 2025 || rok < 1000)
						{
							System.out.println("Prosím zadajte skutočný rok vydania: ");
							rok = Main.over_cislo(sc);
						}
						break;
						
					case 5:
						System.out.println("Zmeniť stav dostupnosti z " + stav(stav) + "? a/n");
						if (sc.next().toLowerCase().equals("a")) stav = !stav;
						break;
					
					case 6:
						run = false;
						break;
				}	
			}
		}
		
		catch(NoSuchElementException | NullPointerException e)
		{
			 System.out.println("Taká kniha neexistuje v knižnici.");
			 sc.nextLine();
		}
	}
	
	public void vypisat_knihu()
	{
		System.out.println("Zadajte názov knihy: ");
		
		try
		{
			String naz = sc.next().toLowerCase();
			
			System.out.println("názov: " + naz);
			if (knihy.get(naz) instanceof Roman)System.out.println("žáner: " + ((Roman)knihy.get(naz)).getZaner());
			if (knihy.get(naz) instanceof Ucebnica)System.out.println("ročník: " + ((Ucebnica)knihy.get(naz)).getRocnik());
			System.out.println("autori: " + String.join(", ", knihy.get(naz).getAutori()) +	"\n"
					+ "rok vydania: " + knihy.get(naz).getRok() +	 						"\n"
					+ "stav: " + stav(knihy.get(naz).getStav()) +							"\n");
			sc.nextLine();
			sc.nextLine();
		}
		
		catch(NoSuchElementException | NullPointerException e)
		{
			 System.out.println("Taká kniha neexistuje v knižnici.");
			 sc.nextLine();
			 sc.nextLine();
		}
	}
	
	public boolean ulozit_knihu()
	{
		System.out.println("Zadajte názov knihy: ");
		FileWriter fw = null;
		BufferedWriter out = null;
		try
		{
			String naz = sc.next().toLowerCase();
			String nazovSuboru = naz + ".txt";
			String typ = null;
			String typ_info = null;
			fw = new FileWriter(nazovSuboru);
			out = new BufferedWriter(fw);

			if (knihy.get(naz) instanceof Roman) 
			{
				typ = "Roman"; 
				typ_info = ((Roman)knihy.get(naz)).getZaner();
			}
			
			else if (knihy.get(naz) instanceof Ucebnica) 
			{
				typ = "Ucebnica";
				typ_info = ((Ucebnica)knihy.get(naz)).getRocnik();
			}
			
			out.write(naz + ";" + typ + ";" + typ_info + ";" + knihy.get(naz).getAutori() + ";" + knihy.get(naz).getRok() + ";" + knihy.get(naz).getStav());
			
			System.out.println("Kniha bola úspešne uložená.");
			sc.nextLine();
			sc.nextLine();
		}
		catch (IOException e) 
		{
			System.out.println("Súbor sa nedá otvoriť / Súbor sa nenašiel.");
			sc.nextLine();
			sc.nextLine();
			return false;
		}
		catch(NoSuchElementException | NullPointerException e)
		{
			 System.out.println("Taká kniha neexistuje v knižnici.");
			 sc.nextLine();
			 sc.nextLine();
			 return false;
		}
		finally
		{
			try
			{	
				if (out != null)
				{
					out.close();
					fw.close();
				}
			}
			catch (IOException e) 
			{
				System.out.println("Súbor sa nedá zavrieť.");
				sc.nextLine();
				return false;
			} 
		}
		return true;
	}
	
	public boolean nacitat_knihu(String nazovSuboru) 
	{
		FileReader fr = null;
		BufferedReader in = null;
		try 
		{
			fr = new FileReader(nazovSuboru);
			in = new BufferedReader(fr);
			String[] castiTextu = in.readLine().split(";");
			
			if(knihy.containsKey(castiTextu[0])) 
			{
				System.out.println("Daná kniha sa už v knižnici nachádza.");
				sc.nextLine();
				return false;
			}
			
			List<String> autori = new ArrayList<>();
			for (String autor : castiTextu[3].split(","))
				autori.add(autor.trim().toLowerCase());
			
			if (castiTextu[1] == "Roman") {knihy.put(castiTextu[0], new Roman(castiTextu[0],castiTextu[2],autori,Integer.parseInt(castiTextu[4]),Boolean.parseBoolean(castiTextu[5])));}
			else if (castiTextu[1] == "Ucebnica") {knihy.put(castiTextu[0], new Ucebnica(castiTextu[0],castiTextu[2],autori,Integer.parseInt(castiTextu[4]),Boolean.parseBoolean(castiTextu[5])));}
			else return false;
			
			System.out.println("Kniha bola úspešne pridaná do knižnice.");
			sc.nextLine();
		}
		catch (IOException e) 
		{
			System.out.println("Súbor sa nedá otvoriť / Súbor sa nenašiel.");
			sc.nextLine();
			return false;
		} 
		catch (NumberFormatException e) 
		{
			System.out.println("Chyba integrity dát v súbore.");
			sc.nextLine();
			return false;
		} 
		finally
		{
			try
			{	
				if (in != null)
				{
					in.close();
					fr.close();
				}
			}
			catch (IOException e) 
			{
				System.out.println("Súbor sa nedá zavrieť.");
				sc.nextLine();
				return false;
			} 
		}
		return true;
	}
	
	public void vypisat_kniznicu()
	{
		int volba;
		boolean run = true;
		List <String> nazvy = new ArrayList<>(knihy.keySet());
		Collections.sort(nazvy);
		while (run)
		{
			System.out.println("Vypísať knižnicu: 	\n"
					+ "1. názvy nezoradené 			\n"
					+ "2. názvy podľa abecedy 		\n"
					+ "3. knihy od daného autora 	\n"
					+ "4. knihy daného žánra 		\n"
					+ "5. požičané knihy			\n"
					+ "6. ukončiť výpis 			\n");
			volba = Main.over_cislo(sc);
			switch(volba)
			{
				case 1:
					List <String> nnazvy = new ArrayList<>(knihy.keySet());
					for (String naz: nnazvy)
					{
						System.out.println("názov: " + naz);
						if (knihy.get(naz) instanceof Roman)System.out.println("žáner: " + ((Roman)knihy.get(naz)).getZaner());
						if (knihy.get(naz) instanceof Ucebnica)System.out.println("ročník: " + ((Ucebnica)knihy.get(naz)).getRocnik());
						System.out.println("autori: " + String.join(", ", knihy.get(naz).getAutori()) +	"\n"
								+ "rok vydania: " + knihy.get(naz).getRok() +	 						"\n"
								+ "stav: " + stav(knihy.get(naz).getStav()) +							"\n");
					}
					break;
					
				case 2:
					for (String naz: nazvy)
					{
						System.out.println("názov: " + naz);
						if (knihy.get(naz) instanceof Roman)System.out.println("žáner: " + ((Roman)knihy.get(naz)).getZaner());
						if (knihy.get(naz) instanceof Ucebnica)System.out.println("ročník: " + ((Ucebnica)knihy.get(naz)).getRocnik());
						System.out.println("autori: " + String.join(", ", knihy.get(naz).getAutori()) +	"\n"
								+ "rok vydania: " + knihy.get(naz).getRok() +							"\n"
								+ "stav: " + stav(knihy.get(naz).getStav()) +							"\n");
					}
					break;
				
				case 3:
					System.out.println("Zadajte autora: ");
					String aut = null;
					
					try
					{
						aut = sc.next().toLowerCase();
					}
					
					catch(NoSuchElementException e)
					{
						 System.out.println("Taký autor neexistuje v knižnici.");
						 sc.nextLine();
					}
					
					for (String naz : nazvy) 
					{
					    Kniha kniha = knihy.get(naz);
					    
						if (kniha.getAutori().contains(aut))
						{
							System.out.println("názov: " + naz);
							if (knihy.get(naz) instanceof Roman)System.out.println("žáner: " + ((Roman)knihy.get(naz)).getZaner());
							if (knihy.get(naz) instanceof Ucebnica)System.out.println("ročník: " + ((Ucebnica)knihy.get(naz)).getRocnik());
							System.out.println("autori: " + String.join(", ", knihy.get(naz).getAutori()) + "\n"
									+ "rok vydania: " + knihy.get(naz).getRok() +		 					"\n"
									+ "stav: " + stav(knihy.get(naz).getStav()) +		 					"\n");
						}
					}
					
					break;
				
				case 4:
					System.out.println("Zadajte žáner: Fantasy/Drama/Thriller/Crime/History");
					String zan = sc.next().toLowerCase();
					zan = najdi_zaner(zan);
					
					for (String naz : nazvy) 
					{
					    Kniha kniha = knihy.get(naz);
					    
						if (kniha instanceof Roman && ((Roman)kniha).getZaner().equals(zan))
						{
							System.out.println("názov: " + naz);
							if (knihy.get(naz) instanceof Roman)System.out.println("žáner: " + ((Roman)knihy.get(naz)).getZaner());
							if (knihy.get(naz) instanceof Ucebnica)System.out.println("ročník: " + ((Ucebnica)knihy.get(naz)).getRocnik());
							System.out.println("autori: " + String.join(", ", knihy.get(naz).getAutori()) +	"\n"
									+ "rok vydania: " + knihy.get(naz).getRok() +	 						"\n"
									+ "stav: " + stav(knihy.get(naz).getStav()) +							"\n");
						}
					}
					break;
					
				case 5:
					for (String naz : nazvy) 
					{
					    Kniha kniha = knihy.get(naz);
					    
						if (!kniha.getStav())
						{
							System.out.println("názov: " + naz);
							if (knihy.get(naz) instanceof Roman)System.out.println("žáner: " + ((Roman)knihy.get(naz)).getZaner());
							if (knihy.get(naz) instanceof Ucebnica)System.out.println("ročník: " + ((Ucebnica)knihy.get(naz)).getRocnik());
							System.out.println("autori: " + String.join(", ", knihy.get(naz).getAutori()) +	"\n"
									+ "rok vydania: " + knihy.get(naz).getRok() +							"\n"
									+ "stav: " + stav(knihy.get(naz).getStav()) +							"\n");
						}
					}
					break;
				
				case 6:
					run = false;
					break;
			}
		}
	}	
	
	public void ulozit_kniznicu()
	{
		SQL sql = new SQL();
		for (Entry<String, Kniha> entry : knihy.entrySet()) 
		{
            String nazov = entry.getKey();
            Kniha kniha = entry.getValue();
            String typ = null;
            String typ_info = null;
            if (kniha instanceof Roman) 
            {
            	typ = "Roman";
            	typ_info = ((Roman) kniha).getZaner();
            }
            if (kniha instanceof Ucebnica) 
            {
            	typ = "Ucebnica";
            	typ_info = ((Ucebnica) kniha).getRocnik();
            }
            List<String> autori = kniha.getAutori();
            int rok = kniha.getRok();
            boolean stav = kniha.getStav();
            sql.ulozit_do_tabulky(nazov, typ, typ_info, autori, rok, stav);
		}
	}
}