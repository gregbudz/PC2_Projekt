import java.util.List;

public class Kniha 
{
	private String nazov;
	private List<String> autori;
	private int rok_vydania;
	private boolean stav_dostupnosti;
	
	Kniha(String nazov, List<String> autori, int rok_vydania, boolean stav_dostupnosti)
	{
		this.nazov = nazov;
		this.autori = autori;
		this.rok_vydania = rok_vydania;
		this.stav_dostupnosti = stav_dostupnosti;
	}

	public String getNazov() {return nazov;}

	public List<String> getAutori() {return autori;}

	public int getRok() {return rok_vydania;}

	public boolean getStav() {return stav_dostupnosti;}
}