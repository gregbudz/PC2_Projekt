import java.util.List;

public class Kniha 
{
	private String nazov;
	private List<String> autori;
	private int rok_vydania;
	private boolean stav_dostupnosti;
	
	Kniha(String nazov, List<String> autori, int rok_vydania, boolean stav_dostupnosti)
	{
		this.nazov = nazov;
		this.autori = autori;
		this.rok_vydania = rok_vydania;
		this.stav_dostupnosti = stav_dostupnosti;
	}

	public String getNazov() {return nazov;}

	public void setNazov(String nazov) {this.nazov = nazov;}

	public List<String> getAutori() {return autori;}

	public void setAutori(List<String> autori) {this.autori = autori;}

	public int getRok() {return rok_vydania;}

	public void setRok(int rok_vydania) {this.rok_vydania = rok_vydania;}

	public boolean getStav() {return stav_dostupnosti;}

	public void setStav(boolean stav_dostupnosti) {this.stav_dostupnosti = stav_dostupnosti;}	
}
