import java.util.List;

public class Roman extends Kniha
{
	private String zaner;
	
	Roman(String nazov, String zaner, List<String> autori, int rok_vydania, boolean stav_dostupnosti)
	{
		super(nazov,autori,rok_vydania,stav_dostupnosti);
		this.zaner = zaner;
	}

	public String getZaner() {return zaner;}

	public void setZaner(String zaner)
	{
		Kniznica kn = new Kniznica();
		this.zaner = kn.najdi_zaner(zaner);
	}
}
